#!/bin/sh
make
sudo make install
sudo cp 99-kromek.rules /etc/udev/rules.d
sudo udevadm control --reload-rules
sudo cp kromekusb.conf /usr/lib/modules-load.d
sudo depmod